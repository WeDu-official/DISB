<img src="https://u.cubeupload.com/wedu/DISBlogo.png" alt="DISBlogo" width="500" />

**DISB** this is the "discord infinity storage bot", it basically turns discord into unlimited cloud storage

<H3>DISB GOT A FULL REMAKE FROM SCRATCH, THIS IS THE NEW STARTUP FOR DISB CALLED "DISB 2.0 (RELEASED IN 5/20/25)"</H3>

**NOTE: DISB got a full scale bug fixes and solving issues that made it unusable and few user improvements in "DISB 2.1 (RELEASED IN 6/11/25)"**

**NOTE2: DISB ONLY work in almost any operating system(\*1) which can support python 3.10 and above**

**\*1: THE DISB wasn't tested on any operating system expect window
and the 32-bit version of it wasn't tested, only window 64-bit operating system was tested**
 
**DISB** is a very powerful way to upload to/download from discord, even if the file is passing the 10 MB per message
limit, and I made it for the sake of people and because I believe it's a right to store and keep the ideas and things
of people written by storing them how matter what and without any cost.

## Install

to install use the following command

<code>pip install DISB</code>

## Contribute

if you have discovered a bug, or you want to change something just open a new issue
at [Issues](https://github.com/WeDu-official/DISB/issues)

## Contact

you can contact us using this [email](mailto:fplu.the.founder@gmail.com)
,and you can be a part of our community by joining [our discord server](https://discord.gg/mnduzx6yUg)